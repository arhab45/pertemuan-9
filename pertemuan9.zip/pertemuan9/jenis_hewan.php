<?php
//
require_once 'class_hewan.php';

//
$burung = new Hewan();
$kucing = new Hewan();

//
$burung->set_name('Burung');
$burung->set_kelamin('Jantan');
$kucing->set_name('Kucing');
$kucing->set_kelamin('Betina');

echo 'Nama Hewan '.$burung->get_name().' Kelaminnya '.$burung->get_kelamin();
echo '<br/>Nama Hewan '.$kucing->get_name().' Kelaminnya '.$kucing->get_kelamin();
?>