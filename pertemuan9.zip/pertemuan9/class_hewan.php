<?php
class Hewan{
    //
    public $name;
    public $kelamin;

    function set_name($name){
        $this->name = $name;
    }

    function set_kelamin($kelamin){
        $this->kelamin = $kelamin;
    }

    function get_name(){
        return $this->name;
    }

    function get_kelamin(){
        $this->kelamin;
        return $this->kelamin;
    }
}
?>